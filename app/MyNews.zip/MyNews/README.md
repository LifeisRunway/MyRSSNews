# MyNews

Application for searching and reading RSS feeds.

Pet project for testing architectural components. Namely: 
- MVP (Moxy);
- Dagger 2;
- Retrofit;
- RxJava;
- Room.
