package com.imra.mynews.mvp.presenters;

/**
 * Date: 27.04.2020
 * Time: 11:04
 *
 * @author IMRA027
 */
public class DetailsPresenter  {
}
