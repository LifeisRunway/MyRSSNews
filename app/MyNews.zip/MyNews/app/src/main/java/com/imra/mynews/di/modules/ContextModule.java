package com.imra.mynews.di.modules;

import android.arch.persistence.room.Room;
import android.content.Context;

import com.imra.mynews.di.common.ArticleDao;
import com.imra.mynews.di.common.MyAppScope;
import com.imra.mynews.di.common.OfflineDB;

import javax.inject.Named;
import javax.inject.Singleton;

import dagger.Module;
import dagger.Provides;

/**
 * Date: 28.07.2019
 * Time: 15:21
 *
 * @author IMRA027
 */

@Module
public class ContextModule {

    private Context mContext;

    public ContextModule(Context context) {
        mContext = context;
    }

    @Provides
    @Singleton
    //@MyAppScope
    public Context provideContext() {
        return mContext;
    }



}
