package com.imra.mynews.di.common;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

import javax.inject.Scope;

/**
 * Date: 31.07.2020
 * Time: 21:06
 *
 * @author IMRA027
 */

@Scope
@Retention(RetentionPolicy.CLASS)
public @interface MyAppScope {
}
