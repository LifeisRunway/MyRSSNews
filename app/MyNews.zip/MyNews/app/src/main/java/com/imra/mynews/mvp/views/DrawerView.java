package com.imra.mynews.mvp.views;

import android.os.Bundle;

import com.arellomobile.mvp.MvpView;
import com.arellomobile.mvp.viewstate.strategy.AddToEndSingleStrategy;
import com.arellomobile.mvp.viewstate.strategy.OneExecutionStateStrategy;
import com.arellomobile.mvp.viewstate.strategy.StateStrategyType;

import java.util.List;
import java.util.Map;

/**
 * Date: 25.07.2020
 * Time: 19:47
 *
 * @author IMRA027
 */

public interface DrawerView extends MvpView {

    @StateStrategyType(OneExecutionStateStrategy.class)
    void setDrawer (Bundle savedInstanceState);

    void setSubItems (Map<String, String> urlsAndIcons);

    void addSubItem (Map<String, String> urlsAndIcons);

    void addNewNewsChannel();

}
